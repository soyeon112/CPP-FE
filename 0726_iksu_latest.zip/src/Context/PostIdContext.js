import { createContext } from 'react';

export const PostIdContext = createContext(null);
