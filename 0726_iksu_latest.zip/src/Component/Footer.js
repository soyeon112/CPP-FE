import React from 'react';
import './Footer.css';

function Footer() {
  return (
    <div className="wrap">
      <div className="footer">
        <p>© 2022 RUPINGPONG</p>
        <p>구현준 김소연 김익수 류승연</p>
      </div>
    </div>
  );
}

export default Footer;
